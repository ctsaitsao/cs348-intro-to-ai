def hello_world():
	return True
